(function ($, $document) {
    "use strict";
    
        $('button[coral-multifield-add]').click(function() {
                var field = $(this).parent();
                var size = field.attr("data-maxitemsallowed");
                if (size) {
                        var ui = $(window).adaptTo("foundation-ui");
                        var totalLinkCount = field.children('coral-multifield-item').length;
                        if (totalLinkCount >= size) {
                                ui.alert("Warning", "Maximum " + size + " items are allowed!", "notice");
                        return false;
                        }
                }
            setTimeout(function(){
                var item = field.find('[data-foundation-validation]');
                item.each(function() {
                    $(this).checkValidity();
                    $(this).updateErrorUI();
                });
            }, 300);

        });
})($, $(document));
