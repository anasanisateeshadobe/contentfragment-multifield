(function (window, $, $document) {
    "use strict";

    var registry = $(window).adaptTo("foundation-registry");

    registry.register("foundation.validation.validator", {
        selector: "coral-numberinput.changi-text",
        validate: function (el) {
           return false;

        }
    });


    $document.on("foundation-contentloaded", function () {
    	
    	var text = $(".coral3-Multifield-item").find("coral-numberinput.changi-number");
        $(text).each(function () {
        	loadValidation(this);
        });
        $('coral-numberinput.changi-number').change(function () {
        	loadValidation(this);
        });
        
    });
    

    $(document).on("click", ".coral3-Multifield-remove", function(e) {
    	loadValidation(this);
    	enable();
    });
    $(document).on("click", "coral-numberinput.changi-number", function(e) {
    		enable();
    });
    
    $(document).on("input", "coral-numberinput.changi-number", function(e) {
    	if((this.hasAttribute("invalid"))){
    		enable();
    	}
    });
    
    function enable() {
    	var number = $(".coral3-Multifield-item").find("coral-numberinput.changi-number");
    	var invalid = false;
        $(number).each(function () {
        	loadValidation(this);
        	if((this.hasAttribute("invalid"))){
        		invalid = true;
            }
        });
        if (!invalid && number.length != 0) {
        	 var save = $(".button-apply.coral3-Button.coral3-Button--primary");
         	  save.attr("disabled", false);
        }
    }


    /**
     * Using common load validation
     * @param element the element
     */
    function loadValidation(element) {
        $(element).checkValidity();
        $(element).updateErrorUI();
    }

})(window, $, $(document));

