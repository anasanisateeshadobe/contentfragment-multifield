(function (window, $, $document) {
    "use strict";

    var registry = $(window).adaptTo("foundation-registry");

    var CONST = {
        TARGET_GRANITE_UI: '.coral-RichText-editable',
        ERROR_MESSAGE: 'Your text length is {0} but character limit is {1}!',
        CORAL_MULTIFIELD: 'CORAL-MULTIFIELD'
    };

    registry.register("foundation.validation.validator", {
        selector: ".coral-RichText-editable",
        validate: function (el) {
            var $rteField = $(el);
            var maxLength = $rteField.attr("data-maxlength");
            var isRequired = $rteField.attr("aria-required");
            var textLength = $rteField.text().replace(/[\t\n]+/g,'').trim().length;

            if (!textLength && isRequired) {
                el.setAttribute("invalid", "");
                return "Please fill out this field.";
            }

            if (maxLength && textLength > parseInt(maxLength)) {
                el.setAttribute("invalid", "");
                return Granite.I18n.get(CONST.ERROR_MESSAGE, [textLength, maxLength]);
            }
            return false;
        }
    });
    
    

    $(document).on("click", ".coral3-Multifield-remove", function(e) {
        var field = document.querySelectorAll('[aria-invalid="true"]');
        var invalidValues = [];
        Array.from(document.querySelectorAll('[invalid]')).forEach(function(el) {
        	invalidValues.push(el);
        	});
        $(field).each(function () {
        	if(invalidValues.indexOf(this) < 0){
                invalidValues.push(this);
        	}
        });
        var cfmForm =  $(".cfm-Form");
        var invalids = cfmForm.data("form.internal.invalids");
        $(invalids).each(function (index) {
            if (CONST.CORAL_MULTIFIELD !== this.tagName && invalidValues.indexOf(this) < 0) {
            	invalids.splice(invalids.indexOf(this), 1);
            }
        });
        if(invalids.length == 0){
            toggleSave(true);
            toggleTabs(true);
        }
        cfmForm.data("form.internal.invalids", invalids);
    });
    
    $('coral-multifield').delegate(CONST.TARGET_GRANITE_UI,'keyup', function (e) {
        loadValidation(this);
    });


    $(document).on("foundation-contentloaded", function(e) {
        var multifieldItems = $(".coral3-Multifield-item").find(CONST.TARGET_GRANITE_UI);

        $(multifieldItems).each(function () {
            loadValidation(this);
        });
        
        $(CONST.TARGET_GRANITE_UI).change(function () {
            loadValidation(this);
        });
    });


    /**
     * Using common load validation
     * @param element the element
     */
    function loadValidation(element) {
        $(element).checkValidity();
        $(element).updateErrorUI();
    }

    function toggleSave(enable) {
        var applyButton = $(".button-apply")[0];
        if (applyButton) {
            applyButton.disabled = !enable;
        }
    }

    function toggleTabs(enable) {
        var tabList = $("#SidePanel .js-SidePanel-content.js-SidePanel-content--edit coral-tablist")[0];
        Coral.commons.ready(tabList, function () {
            var selectedTab = tabList.selectedItem;
            if (selectedTab) {
                selectedTab.invalid = !enable;
                tabList.items.getAll().forEach(function(tab) {
                    if (!tab.selected) {
                        tab.disabled = !enable ? true : false;
                    }
                });
            }
        });
    }
})(window, $, $(document));